namespace Unity.PlasticSCM.Editor.StatusBar
{
    internal interface INotificationContent
    {
        void OnGUI();
    }
}
